import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import linregress

def analyze_coastdown(csv_file):
    # Load data
    df = pd.read_csv(csv_file)

    # Ensure expected columns exist
    if not {'t','v','u'}.issubset(df.columns):
        raise ValueError("CSV must contain columns: 't', 'v', 'u'")

    # Preprocessing:
    # keep only rows where acceleration == 0 and velocity > 0
    df = df[(df['u'] == 0) & (df['v'] > 0.05)].copy()

    if df.empty:
        raise ValueError("No valid coastdown data after filtering.")

    t = df['t'].values
    v = df['v'].values

    # Linear regression (v = slope*t + intercept)
    slope, intercept, r_value, p_value, std_err = linregress(t, v)
    v_fit = slope * t + intercept

    # Plot velocity vs time
    plt.figure(figsize=(8,5))
    plt.scatter(t, v, s=15, label='Filtered data', color='blue')
    plt.plot(t, v_fit, 'r-', linewidth=2, label=f'Fit: v = {slope:.3f}·t + {intercept:.3f}')
    
    plt.title("Coastdown Test - Velocity vs Time")
    plt.xlabel("Time [s]")
    plt.ylabel("Velocity [m/s]")
    plt.legend()
    plt.grid(True)
    plt.show()

    # Print regression results
    print("Linear regression results (filtered data):")
    print(f"  Slope (deceleration): {slope:.6f} m/s²")
    print(f"  Intercept: {intercept:.6f} m/s")
    print(f"  R²: {r_value**2:.6f}")

# Example usage:
analyze_coastdown("fva_ws/src/solution_stack/scripts/CoastdownLog.csv")
