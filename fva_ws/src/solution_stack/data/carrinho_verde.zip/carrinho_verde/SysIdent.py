import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import MinMaxScaler
from scipy import signal

# --------------------------
# 1️⃣ Load CSV data
# --------------------------
data = pd.read_csv('/home/leordp/UFMG/VeiculosAutonomos/fva_ws/src/solution_stack/scripts/logs/log_car_600s.csv')  # replace with your CSV path
inputs = data[['u', 'steer']].values
outputs = data[['v', 'qx', 'qy', 'qz', 'qw']].values

# --------------------------
# 2️⃣ Prepare NLARX data
# --------------------------
n_lag_output = 3  # past outputs
n_lag_input = 3   # past inputs

X, Y = [], []
for i in range(max(n_lag_output, n_lag_input), len(outputs)):
    x_sample = []
    # past outputs
    for j in range(n_lag_output):
        x_sample.extend(outputs[i - n_lag_output + j])
    # past inputs
    for j in range(n_lag_input):
        x_sample.extend(inputs[i - n_lag_input + j])
    X.append(x_sample)
    Y.append(outputs[i])

X = np.array(X)
Y = np.array(Y)

# Scale data
scaler_X = MinMaxScaler()
scaler_Y = MinMaxScaler()
X_scaled = scaler_X.fit_transform(X)
Y_scaled = scaler_Y.fit_transform(Y)

# Convert to tensors
X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
Y_tensor = torch.tensor(Y_scaled, dtype=torch.float32)
dataset = TensorDataset(X_tensor, Y_tensor)
loader = DataLoader(dataset, batch_size=32, shuffle=True)

# --------------------------
# 3️⃣ Define NLARX model
# --------------------------
class NLARXNet(nn.Module):
    def __init__(self, input_size, output_size, hidden_size=64):
        super(NLARXNet, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size)
        )
    def forward(self, x):
        return self.net(x)

input_size = X.shape[1]
output_size = Y.shape[1]
model = NLARXNet(input_size, output_size)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# --------------------------
# 4️⃣ Train the model
# --------------------------
n_epochs = 200
for epoch in range(n_epochs):
    for xb, yb in loader:
        optimizer.zero_grad()
        pred = model(xb)
        loss = criterion(pred, yb)
        loss.backward()
        optimizer.step()
    if (epoch+1) % 20 == 0:
        print(f"Epoch {epoch+1}/{n_epochs}, Loss: {loss.item():.6f}")

# --------------------------
# 5️⃣ Linearize around operating point
# --------------------------
x_op = X_tensor[0].unsqueeze(0).requires_grad_(True)  # choose first sample as operating point
y_op = model(x_op)

# Compute Jacobian w.r.t inputs (last n_lag_input*2 entries correspond to u, steer)
jacobian_input = []
for i in range(y_op.shape[1]):
    grad = torch.autograd.grad(y_op[0, i], x_op, retain_graph=True)[0]
    # extract only input part
    grad_input = grad[0, -n_lag_input*2:].detach().numpy()
    jacobian_input.append(grad_input)
jacobian_input = np.array(jacobian_input)  # shape: [output_dim, input_dim]
print("Jacobian (A) shape:", jacobian_input.shape)

# --------------------------
# 6️⃣ Estimate discrete-time transfer functions
# --------------------------
# We'll treat each output-input pair separately
transfer_functions = {}
dt = data['t'].iloc[1] - data['t'].iloc[0]  # sample time

for out_idx, out_name in enumerate(['v','qx','qy','qz','qw']):
    for in_idx, in_name in enumerate(['u','steer']):
        # Gain approximation from linearization
        gain = jacobian_input[out_idx, in_idx]  # slope
        # simple first-order discrete-time transfer function: y[k+1] = gain * u[k]
        b = [gain]        # numerator
        a = [1, 0]        # denominator y[k+1] - y[k] = gain*u[k]
        tf_discrete = signal.dlti(b, a, dt=dt)
        transfer_functions[f"{out_name}/{in_name}"] = tf_discrete

# Print example transfer function
for key, tf in transfer_functions.items():
    print(f"{key}: numerator={tf.num}, denominator={tf.den}, dt={tf.dt}")
